from django.apps import AppConfig


class FileManagerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'file_manager_app'
